## Imports 
from multiprocessing import Value
from threading import Timer
from util import*
import multiprocessing
import random
import socket
import time
import sys


def send(sock,message,IP,Port,type):
    sock.sendto(message, (IP, Port))
    printSending(int(message[:16], 2),type)


#Helper Method for seqNum
def rand_int():
    go = True
    while go:
        r = random.randint(0,(2 ** 5)-1)
        if r < 30720:
            go = False
    return r 



class Client:
    def __init__(self,sock,IP,Port):
        self.closed = True
        self.syn = False
        self.IP = IP
        self.Port = Port
        self.handshake(sock)
    def handshake(self,sock):
        if self.closed:
            seqNum = rand_int()
            synHeader = Header(seqNum,1,1,0,1,0)
            send(sock,synHeader.bytes(),self.IP,self.Port,"SYNACK")
            self.closed = False
        else:
            pass

    def terminate(self):
        self.sock.close()

    def checkAck(self,lastAck):
        go = True
        while go:
            data , addr = self.sock.recvfrom(1)
            header = decodeHeader(data)
            if header.ackNum > lastAck:
                lastAck.value = header.ackNum
    def recvAck(self):
        lastAck = Value('i', self.lastAck)
        multi = multiprocessing.Process(target = self.checkAck,args = (lastAck))
        multi.start()
        multi.join(1)
        if multi.is_alive():
            multi.terminate()
            multi.join()
        self.lastAck = lastAck.value


#Main Method 
def main(ip,port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP
    client = Client(sock,ip,port)


if __name__ == "__main__":
    if len(sys.argv) != 3: 
        sys.exit("Usage: python simple-tcp-client.py SERVER-HOST-OR-IP PORT-NUMBER") 
    receiver_ip = sys.argv[1] 
    receiver_port = int(sys.argv[2])
    main(receiver_ip,receiver_port)
